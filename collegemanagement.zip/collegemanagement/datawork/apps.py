from django.apps import AppConfig


class DataworkConfig(AppConfig):
    name = 'datawork'
