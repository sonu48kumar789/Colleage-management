from django.shortcuts import render, redirect
from .forms import *
from .models import *
from django.db.models import Q
from django.db.models import Count,Sum
# Create your views here.


def index(r):
    data = {
        "course":Course.objects.all()
    }
    return render(r, 'index.html',data)

def apply(r):
    form = InsertStudent(r.POST or None, r.FILES or None)
    data = {"insert_form": form}
    if r.method == "POST":
        if form.is_valid():
            form.save()
            return redirect(apply)
        else:
            return render(r, 'apply.html', data)
    return render(r, 'apply.html', data)



def student_login(r):
    if r.method == "POST":
        email = r.POST.get('email')
        password = r.POST.get('password')

        condition = Q(email=email) & Q(password=password)
        check = Student.objects.filter(condition).count()
        if(check > 0):
            r.session['student_log'] = email
            return redirect(student_dashboard)
        else:
            return redirect(student_login)
    return render(r,'login.html')

def logout(r):
    if r.session.has_key('student_log'):
        del r.session['student_log']
    return redirect(student_login)



def student_dashboard(r):
    if not r.session.has_key('student_log'):
        return redirect(student_login)

    log = r.session['student_log']
    std = Student.objects.get(email=log).roll

    data = {
        "student": Student.objects.filter(roll=std),
    }
    return render(r,'student/student_dashboard.html',data)

def student_setting(r):
    if not r.session.has_key('student_log'):
        return redirect(student_login)

    log = r.session['student_log']
    std = Student.objects.get(email=log).roll


    data = {
        "student": Student.objects.filter(roll=std),

    }
    return render(r, 'student/student_setting.html',data)

def search(r):
    if r.method == "GET":
        searchdata = r.GET.get('search')
        data = {
            "course": Course.objects.filter(course_title__icontains=searchdata),
            "student": Student.objects.all()

        }
        return render(r,'index.html',data)
    else:
        return redirect(index)