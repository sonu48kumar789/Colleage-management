from django.db import models
from django.utils import timezone

# Create your models here.


class Course(models.Model):
    course_id = models.AutoField(primary_key=True)
    course_title = models.CharField(max_length=200)

    def __str__(self):
        return self.course_title


class Student(models.Model):
    roll = models.AutoField(primary_key=True)
    full_name = models.CharField(max_length=200)
    father_name = models.CharField(max_length=200)
    mother_name = models.CharField(max_length=200)
    gender = models.CharField(max_length=200)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    contact = models.IntegerField()
    email = models.EmailField()
    photo = models.ImageField(upload_to="media/")
    address = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    dob = models.DateField()
    status = models.IntegerField(default=0)
    date_of_creation = models.DateTimeField(default=timezone.now)
    password = models.CharField(max_length=200)

    def __str__(self):
        return self.full_name

